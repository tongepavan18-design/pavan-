/*
Name: Pavan Tonge
PRN No: 2502508111242035
Batch: B
*/

public class ArithmeticOperatorsDemo {
    public static void main(String[] args) {
        // 1. Declare and initialize two integer variables
        int num1 = 32;
        int num2 = 16;
        int result;

        // 2. Addition
        result = num1 + num2;
        System.out.println("num1 + num2 = " + result);

        // 3. Subtraction
        result = num1 - num2;
        System.out.println("num1 - num2 = " + result);

        // 4. Multiplication
        result = num1 * num2;
        System.out.println("num1 * num2 = " + result);

        // 5. Integer Division
        result = num1 / num2;
        System.out.println("num1 / num2 (integer division) = " + result);

        // 6. Modulus (Remainder)
        result = num1 % num2;
        System.out.println("num1 % num2 (remainder) = " + result);

        // 7. Demonstration of floating-point division
        double doubleResult = (double) num1 / num2;
        System.out.println("num1 / num2 (floating-point division) = " + doubleResult);
    }
}

// The output for the code above will be:
// num1 + num2 = 48
// num1 - num2 = 16
// num1 * num2 = 512
// num1 / num2 (integer division) = 2
// num1 % num2 (remainder) = 0
// num1 / num2 (floating-point division) = 2.0
